//
//  FoodCategory.swift
//  FoodsDemo
//
//  Created by Sateesh Yegireddi on 03/10/18.
//  Copyright © 2018 Company. All rights reserved.
//

import Foundation

class FoodCategory
{
    var name: String
    var foodItems: [FoodItem]
    
    init() {
        
        name = ""
        foodItems = []
    }
    
    static func getCategories(from dict: [String: Any]) -> [FoodCategory] {
        
        var foodCategories = [FoodCategory]()
        
        for (categoryName, categoryItems) in dict {
            
            let foodCategory = FoodCategory()
            
            foodCategory.name = categoryName
            
            if let items = categoryItems as? [[String: Any]] {
                
                for item in items {
                    
                    foodCategory.foodItems.append(FoodItem(item))
                }
            }
            
            foodCategories.append(foodCategory)
        }
        
        return foodCategories
    }
}

class FoodItem
{
    /*
    "menu_description": "Small pieces of beef, goat, stipe, and tendon saut in crushed green Jamaican pepper.",
    "menu_id": 78,
    "menu_name": "ATA RICE",
    "menu_photo": "http://192.168.1.141/TastyIgniter-master/admin/../assets/images/data/3.jpeg",
    "menu_price": "12.0000"
    */
    var id: Int
    var name: String
    var photo: String
    var price: String
    var itemDescription: String
    
    init() {
        
        id = 0
        name = ""
        photo = ""
        price = ""
        itemDescription = ""
    }
    
    init(_ dict: [String: Any]?) {
        
        id = dict?["menu_id"] as? Int ?? 0
        
        name = dict?["menu_name"] as? String ?? ""
        
        photo = dict?["menu_photo"] as? String ?? ""
        
        price = dict?["menu_price"] as? String ?? ""
        
        itemDescription = dict?["menu_description"] as? String ?? ""

    }
}
