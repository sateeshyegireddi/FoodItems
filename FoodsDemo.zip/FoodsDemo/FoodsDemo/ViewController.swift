//
//  ViewController.swift
//  FoodsDemo
//
//  Created by Sateesh Yegireddi on 03/10/18.
//  Copyright © 2018 Company. All rights reserved.
//

import UIKit

class ViewController: UIViewController
{
    @IBOutlet weak var foodTableView: UITableView!
    
    var foodCategories: [FoodCategory]!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        let contents = loadDataFromJSONFile()
        
        foodCategories = parseResponse(contents)
        
        //Filter for non-zero food items
        foodCategories = foodCategories.filter({ $0.foodItems.count > 0 })
        
        foodTableView.register(UINib(nibName: "FoodItemCell", bundle: nil), forCellReuseIdentifier: "FoodItemCell")
        
        foodTableView.reloadData()
    }
    
    //MARK: - Fetch data from API.
    // Its possibly, the data will be coming from the API Server.
    func loadDataFromJSONFile() -> [String: Any]? {
        
        if let path = Bundle.main.path(forResource: "foodcategories.json", ofType: nil) {
            if let contentsData = FileManager.default.contents(atPath: path) {
                
                do {
                    let contents = try JSONSerialization.jsonObject(with: contentsData, options: .mutableContainers)
                    return contents as? [String : Any]
                } catch let error {
                    print(error)
                }
            }
        }
        return nil
    }
    
    //MARK: - Parse useful data
    func parseResponse(_ responseData: [String: Any]?) -> [FoodCategory] {
        
        //Create food categories empty array to return non-nil value
        var categories = [FoodCategory]()
        
        if let Response = responseData?["Response"] as? [String: Any] {
            
            if let response = Response["response"] as? [String: Any] {
            
                if let data = response["data"] as? [String: Any] {
                    
                    categories = FoodCategory.getCategories(from: data)
                }
            }
        }
        return categories
    }
}

extension ViewController: UITableViewDataSource, UITableViewDelegate {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        
        return foodCategories.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return foodCategories[section].foodItems.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        return UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "FoodItemCell", for: indexPath) as! FoodItemCell
        
        cell.nameLabel.text = foodCategories[indexPath.section].foodItems[indexPath.row].name
        cell.descriptionLabel.text = foodCategories[indexPath.section].foodItems[indexPath.row].itemDescription
        cell.priceLabel.text = foodCategories[indexPath.section].foodItems[indexPath.row].price

        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        
        return 50
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        let sectionHeader = Bundle.main.loadNibNamed("SectionHeader", owner: self, options: nil)![0] as! SectionHeader
        sectionHeader.titleLabel.text = foodCategories[section].name
        return sectionHeader
    }
}
