//
//  FoodItemCell.swift
//  FoodsDemo
//
//  Created by Sateesh Yegireddi on 03/10/18.
//  Copyright © 2018 Company. All rights reserved.
//

import UIKit

class FoodItemCell: UITableViewCell {

    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var descriptionLabel: UILabel!
    @IBOutlet weak var priceLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
}
