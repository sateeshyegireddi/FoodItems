//
//  SectionHeader.swift
//  FoodsDemo
//
//  Created by Sateesh Yegireddi on 03/10/18.
//  Copyright © 2018 Company. All rights reserved.
//

import UIKit

class SectionHeader: UIView
{
    
    @IBOutlet weak var titleLabel: UILabel!
    
}
